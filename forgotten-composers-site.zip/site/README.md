# Forgotten British Composers 1850–1950

Static site for GitHub Pages. Put audio in `audio/` using the filenames in each composer page, then push. In repo Settings → Pages, deploy from the `main` branch, root folder.

To add a composer: copy a file in `composers/`, edit it, and add a card to `index.html`.
